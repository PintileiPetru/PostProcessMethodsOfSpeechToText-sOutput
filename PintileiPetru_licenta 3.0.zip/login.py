from tkinter import *
from tkinter import messagebox
import hashlib

import connect_to_database as DB

# Verificare logare
def check_login(username, password):

    # căutarea utilizatorului în colecția utilizatorilor
    user = DB.users_collection.find_one({"username": username})

    if user and user["password"] == password:
        return True
    else:
        return False

def Login(entry_username, entry_password):
    DB.Database()
    username = entry_username.get()
    password = entry_password.get()

    # Creare instanță sha256
    sha256 = hashlib.sha256()

    # Convertirea parolei în bytes
    password_bytes = password.encode('utf-8')

    # Aplicarea sha256 pe parolă
    sha256.update(password_bytes)

    # Obținerea valorii hash pentru parolă
    hashed_password = sha256.hexdigest()


    # definește query-ul pentru utilizatorul curent
    query = {"username": username}

    # extrage utilizatorul curent
    this_user = DB.users_collection.find_one(query)

    if this_user:
        # obține valoarea "role" al utilizatorului curent
        user_role = this_user.get("role")

        if check_login(username, hashed_password):
            if user_role=="user":
                messagebox.showinfo("Login", "Autentificare cu succes!")
                user_array = ["user", str(username)]
                return(user_array)
                #ToogleToMainwindow(username)
            else:
                messagebox.showinfo("Login", "Autentificare cu succes!\nAcesta este un cont de administrator!")
                admin_array = ["admin", str(username)]
                return(admin_array)
                #ToogleToAdminWindow(username)
        else:
            messagebox.showerror("Login", "Parolă greșită!")
    else:
        messagebox.showerror("Login", "Date de autentificare invalide!")

