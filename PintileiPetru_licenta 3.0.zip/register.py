from tkinter import *
from tkinter import messagebox
import hashlib

import connect_to_database as DB

def Register(entry_register_username, entry_register_email, entry_register_password, entry_register_confirm_password):
    DB.Database()
    username = entry_register_username.get()
    email = entry_register_email.get()
    password = entry_register_password.get()
    confirm_password = entry_register_confirm_password.get()

    # Verific dacă toate câmpurile sunt completate
    if username == "" or password == "" or email == "":
        messagebox.showerror("Campuri necompletate", "Toate campurile sunt obligatorii. Va rugam completati din nou.")
        return
    
    # Verific dacă parolele coincid
    if password != confirm_password:
        messagebox.showinfo("Parola gresita", "Parolele nu coincid. Incercati din nou.")
        return

    # Verific dacă utilizatorul există deja în baza de date
    coll = DB.db.Users
    existing_user = coll.find_one({"username": username})
    if existing_user:
        messagebox.showinfo("Utilizator existent", "Utilizatorul există deja in baza de date. Incearca un alt nume de utilizator.")
        return

    # Creare instanță sha256
    sha256 = hashlib.sha256()

    # Convertirea parolei în bytes
    password_bytes = password.encode('utf-8')

    # Aplicarea sha256 pe parolă
    sha256.update(password_bytes)

    # Obținerea valorii hash pentru parolă
    hashed_password = sha256.hexdigest()

    # adauga utilizatorul in baza de date
    user = {"username": username, "password": hashed_password, "email": email, "role": "user",
             "text_inputs": [], "text_entities": [], "text_senteces": [], "text_speech_parts": []}
    DB.users_collection.insert_one(user)

    # afiseaza un mesaj de confirmare
    messagebox.showinfo("Inregistrare", f"Utilizatorul {username} a fost inregistrat cu succes!")