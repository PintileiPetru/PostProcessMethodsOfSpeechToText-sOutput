import os
from tkinter import messagebox
from tkinter import filedialog
import speech_recognition as sr
import soundfile as sf

def mp3_to_wav_convert(mp3file_path):

    wavfile_name, ext = os.path.splitext(os.path.basename(mp3file_path))
    #print(wavfile_name)

    wavfile_path = f"./Audio_files/{wavfile_name}_converted_to_WAV.wav"

    # Load the audio file using soundfile
    audio_data, sample_rate = sf.read(mp3file_path)

    # Convert the audio to WAV format and save the output file using soundfile
    sf.write(wavfile_path, audio_data, sample_rate, format="WAV")

    return wavfile_path


def transcribe_wav_file():
    current_dir=os.getcwd()
    wav_dir = os.path.join(current_dir, "Audio_files")
    
    try:
    
        file_path = filedialog.askopenfilename(initialdir=wav_dir, title="Select file",
                                              filetypes=(("Audio files", "*.mp3 *.wav"), ("All files", "*.*")))
        
        # Get file extension using os.path.splitext()
        # wavfile_name=os.path.splitext(file_path)[0]

        # print(wavfile_name)
        # print("\t")
        file_extension = os.path.splitext(file_path)[1]
        
        #print(file_extension)
        
        if file_path:

            if file_extension == ".mp3":
                wavfile_path=mp3_to_wav_convert(file_path)
                                            
                return transcribe_wavfile_totext(wavfile_path)
                
            elif file_extension == ".wav":
                return transcribe_wavfile_totext(file_path)

            else:
                messagebox.showerror("Citire fisier audio.", f"Fisierul {file_path} nu este de tip .mp3 sau .wav!")
        else:
            messagebox.showerror("Citire fisier audio.", f"Fisierul {file_path} nu exista!")
    except ValueError:
        messagebox.showerror("Citire fisier audio.", f"Fisierul {file_path} nu este de tip .mp3 sau .wav!")


def transcribe_wavfile_totext(filename):
    
    r = sr.Recognizer()

    # transcribe audio file                                                         
    AUDIO_FILE = f"{filename}"

    # preluam continutul fisierului .wav
    with sr.AudioFile(AUDIO_FILE) as source:
        audio = r.record(source)

        # transcriem continutul folosind recognize_google
        try:
            #print("Transcription: " + r.recognize_google(audio, language='ro-RO'))
            text = r.recognize_google(audio, language='ro-RO')
            messagebox.showinfo("Transcriere fisier audio", "Transcrierea fisierului audio a avut loc cu succes!")

        except sr.UnknownValueError:
            messagebox.showerror("Transcriere fisier audio", "Transcrierea fisierului audio nu a avut loc cu succes!")            
        except sr.RequestError as e:
            messagebox.showerror("Transcriere fisier audio", "Transcrierea fisierului audio nu a avut loc cu succes!\n")            
            print("Nu am putut efectua cererea catre serviciul Sphinx; {0}".format(e))

    return text #returnează textul transcris
