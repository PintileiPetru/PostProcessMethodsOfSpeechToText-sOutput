from tkinter import *
import spacy
from spacy.lang.ro.stop_words import STOP_WORDS
#from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

#import word_correction

# definim o functie care sa traduca etichetele pentru entitati
def translate_label(label):

    # definim un dictionar pentru a traduce etichetele de entitati numite   
    label_map = {
        "PER": "PERSOANĂ",
        "ORG": "ORGANIZAȚIE",
        "LOC": "LOCAȚIE",
        "MISC": "DIVERSE",
        "CARDINAL": "CIFRE",
        "DATE": "DATE",
        "EVENT": "EVENIMENTE",
        "FAC": "CLĂDIRI ȘI FACILITĂȚI",
        "GPE": "ENTITĂȚI GEOGRAFICE POLITICE",
        "LANGUAGE": "LIMBI",
        "LAW": "LEGI ȘI ACTE JURIDICE",
        "MONEY": "VALUTE ȘI ALTE UNITĂȚI MONETARE",
        "NORP": "GRUPURI ETNICE SAU NAȚIONALE",
        "ORDINAL": "ORDINE ȘI POZIȚII ÎN SECVENȚE",
        "PRODUCT": "OBIECTE, VEHICULE ȘI ALTE PRODUSE",
        "QUANTITY": "MĂSURI ȘI ALTE VALORI MĂSURABILE",
        "TIME": "TIMP",
        "NUMERIC_VALUE": "VALOARE NUMERICĂ",
        "PERSON": "PERSOANĂ",
        "ORGANIZATION": "ORGANIZAȚIE",
        "FACILITY": "LOCAȚIE",
        "DATETIME": "DATE DE TIMP",
        "NAT_REL_POL": "LOCAȚIE",
        "WORK_OF_ART": "OPERĂ DE ARTĂ"
    }

    return label_map.get(label, label)

# definim o functie care sa traduca etichetele
def translate_part_of_speech(label):

    parti_vorbire_ro = {
    "ADJ": "ADJECTIV",
    "ADP": "PREPOZIȚIE",
    "ADV": "ADVERB",
    "AUX": "VERB",
    "CONJ": "CONJUNCȚIE",
    "CCONJ": "CONJUNCȚIE COORDONATOARE",
    "DET": "ARTICOL",
    "INTJ": "INTERJECȚIE",
    "NOUN": "SUBSTANTIV",
    "NUM": "NUMERAL",
    "PART": "PART",
    "PRON": "PRONUME",
    "PROPN": "SUBSTANTIV PROPRIU",
    "PUNCT": "SEMN DE PUNCTUAȚIE",
    "SCONJ": "CONJUNCȚIE SUBORDONATOARE", 
    "SYM": "SYM",
    "VERB": "VERB",
    "SPACE": "",
    "X": "X"
}

    return parti_vorbire_ro.get(label, label)

# definim o functie pentru post-procesarea textului
def PostProcess(inital_text, processed_text_widget, entity_text_widget, speech_part_text_widget, senteces_text_widget):
    
    # Eliminam literele care se repeta.
    #text = re.sub(r"(.)\1+", r"\1", text)

    # Încărcați modelul Sapcy pentru limba romana
    nlp = spacy.load('ro_core_news_lg') # varianta foarte mare (40 MB)
                    #ro_core_news_md varianta mare
    
    doc = nlp(inital_text)
    
    #1
    # creăm o listă de cuvinte procesate cu etichetele POS înlocuite cu echivalentele lor în limba română
    processed_words = []

    for token in doc:
        # afisam predictiile si probabilitatile acestora pentru fiecare cuvant in parte
        #word_correction.correct_word(token.text)
        
        # dacă cuvântul este un semn de punctuație, îl adăugăm fără spațiu înainte
        if token.is_punct or token.text == "-":
            processed_words.append(token.text)
        else:
            processed_words.append(" " + token.text)

    # unim cuvintele procesate pentru a obține textul final
    processed_text = "".join(processed_words)

    #Stergere continut processed_text_widget
    processed_text_widget.delete(1.0, END)

    #Inserare continut nou
    processed_text_widget.insert("1.0", processed_text)

    #2
    #stergem continutul actual al senteces_text_widget
    senteces_text_widget.delete(1.0, END)

    # Afișarea propozițiilor din text
    for sentence in doc.sents:
        #inseram propozitiile in senteces_text_widget
        senteces_text_widget.insert(END, str(sentence) + "\n\n")

    #3
    #stergem continutul actual al entity_text_widget
    entity_text_widget.delete(1.0, END)

    # afișăm entitățile numite traducând etichetele
    entitati_adaugate = set()  # set pentru a reține entitățile deja adăugate
    
    for ent in doc.ents:
        # verificăm dacă entitatea a fost deja adăugată
        if ent.text not in entitati_adaugate:
            # inserăm entitatea numită în entity_text_widget
            entity_text_widget.insert(END, str(ent.text) + " " + translate_label(ent.label_) + "\n")
            entitati_adaugate.add(ent.text)
    #4
    #stergem continutul actual al speech_part_text_widget
    speech_part_text_widget.delete(1.0, END)

    # afisam partile de vorbire traducand etichetele
    for token in doc:
        #inseram cuvintele și etichetele lor de parte de vorbire
        speech_part_text_widget.insert(END, str(token.text) + " " + translate_part_of_speech(token.pos_) + "\n")

        #afisam dependentele sintactice intre cuvinte
        #print(token.text, token.dep_, token.head.text, token.head.pos_)

    #5
    #Analiza sentiment
    #nltk.download('vader_lexicon')
    # sia = SentimentIntensityAnalyzer()
    # sentiment_score = sia.polarity_scores(inital_text)['compound']

    # sentiment_label = "pozitiv" if float(sentiment_score) >= 0 else "negativ"
    # print(f"\nTextul are un scor de sentiment de {sentiment_score} și este considerat {sentiment_label}.")


    # sumarizarea textului
    # Eliminarea cuvintelor de oprire
    # stopwords = list(STOP_WORDS)
    # # Calcularea scorului pentru fiecare propoziție
    # sentence_scores = {}
    # for sent in doc.sents:
    #     for word in sent:
    #         if word.text.lower() in stopwords:
    #             continue
    #         if sent not in sentence_scores.keys():
    #             sentence_scores[sent] = word.sentiment.polarity
    #         else:
    #             sentence_scores[sent] += word.sentiment.polarity

    # # Obținerea celor mai importante propoziții
    # summary_sentences = heapq.nlargest(2, sentence_scores, key=sentence_scores.get)

    
    # # Unirea propozițiilor într-un sumar
    # summary = [sent.text for sent in summary_sentences]
    # summary = ' '.join(summary)

    # print(f"Textul sumarizat:\n{summary}")

    # afișăm textul procesat
    #print("\nTextul procesat:\n" + str(processed_text) +"\n")

    return processed_text
