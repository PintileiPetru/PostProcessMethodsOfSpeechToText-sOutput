import pymongo
from pymongo.errors import ConfigurationError
from dns.resolver import LifetimeTimeout
from tkinter import messagebox

def Database():
    # creeaza conexiunea cu baza de date
    global client, db, users_collection
    try:
        client = pymongo.MongoClient("mongodb+srv://pintilei:1234@speechtotextdb.cdqhghy.mongodb.net/?retryWrites=true&w=majority")
    except ConfigurationError:
        messagebox.showerror("Login", "Eroare de conectare la baza de date!")
    db = client["sttDB"]
    users_collection = db["Users"]