import os
from gtts import gTTS
from tkinter import messagebox
from datetime import datetime

import connect_to_database as DB


#definirea funcției pentru a transforma textul în vorbire folosind biblioteca gTTS
def save_mp3files(username, preprocessed_text):

    if preprocessed_text!="":
        # definește query-ul pentru utilizatorul curent
        query = {"username": username}

        # extrage utilizatorul curent
        this_user = DB.users_collection.find_one(query)

        # obține vectorul "text_inputs" al utilizatorului curent
        text_inputs = this_user.get("text_inputs")

        # definește calea către folderul pentru utilizator
        folder_path = os.path.join(os.getcwd(), "Users", username, f"{username} text inputs in audio format")

        # creează folderul dacă nu există
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        # salvează fiecare element din vectorul "text_inputs" ca fișier .mp3
        start=1
        try:
            for index, value in enumerate(text_inputs):
                start=index+1
                if value==preprocessed_text:
                    # definește numele fișierului .mp3
                    file_name = f"{username}_text_input_{start}.mp3"
    
                    # definește calea către fișierul .mp3
                    file_path = os.path.join(folder_path, file_name)
    
                    # verifică dacă fișierul există deja și il șterge în caz afirmativ
                    if os.path.exists(file_path):
                        os.remove(file_path)
                    # convertește string-ul în format audio .mp3
                    tts = gTTS(text=value, lang="ro")
                    tts.save(file_path)
                else:
                    # definește numele fișierului .mp3
                    current_datetime = datetime.now()
                    current_datetime = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
                    current_datetime = current_datetime.replace(":", "-")
                    file_name = f"{username}_text_input_{current_datetime}.mp3"
    
                    # definește calea către fișierul .mp3
                    file_path = os.path.join(folder_path, file_name)
    
                    # verifică dacă fișierul există deja și il șterge în caz afirmativ
                    if os.path.exists(file_path):
                        os.remove(file_path)
                    # convertește string-ul în format audio .mp3
                    tts = gTTS(text=preprocessed_text, lang="ro")
                    tts.save(file_path)
                    break
                #print("1  " + str(file_name) + "    text:  " + tts + "\n")

            messagebox.showinfo("mp3 files", "Fisiere mp3 create cu succes!")

        except ValueError:
            messagebox.showinfo("mp3 files", "Eroare la salvarea fisierelor .mp3. Incercati din nou.")

        except TypeError:
            messagebox.showinfo("mp3 files", "Eroare la salvarea fisierelor .mp3. Incercati din nou.")
    else:
        messagebox.showerror("txt file", "Câmpul <Text după corectarea erorilor> este gol.\nÎncercați din nou.")