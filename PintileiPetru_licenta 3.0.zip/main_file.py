from tkinter import *
import tkinter.simpledialog as simpledialog
from tkinter import messagebox
import os

#importam fisierele auxiliare
import speech_to_text as stt
import wav_transcribe as wt
import save_txt_files as stf
import post_process as pp
import register as reg
import login as log
import connect_to_database as DB
import save_audio_files as saf

root = Tk()
root.title("Post-processing methods of speech-to-text's output")

# setarea dimensiunilor ferestrei egale cu dimensiunea ecranului
width = root.winfo_screenwidth()
height = root.winfo_screenheight()
root.geometry("%dx%d" % (width, height))
root.state('zoomed')

# Functie de iesire din aplicatie
def Exit():
    root.destroy()
    exit()

# Crearea variabilei de tip IntVar pentru a stoca valoarea selectată
var = IntVar()

# Definirea funcției care va fi apelată atunci când se selectează un buton radio
def select(text_entities_label, entity_text_widget,
           text_sentece_label, senteces_text_widget,
           part_of_speech_label, speech_part_text_widget):
    #1 entitati
    #2 propozitii
    #3 parti de vorbire
    #print("Valoarea selectată este: ", var.get())

    if(var.get()==1):
        text_sentece_label.grid_remove()
        senteces_text_widget.grid_remove()
        
        part_of_speech_label.grid_remove()
        speech_part_text_widget.grid_remove()

        text_entities_label.grid(row=5, column=2)
        entity_text_widget.grid(row=6, column=2)

    if(var.get()==2):
        text_entities_label.grid_remove()
        entity_text_widget.grid_remove()

        part_of_speech_label.grid_remove()
        speech_part_text_widget.grid_remove()

        text_sentece_label.grid(row=5, column=2)
        senteces_text_widget.grid(row=6, column=2)

    if(var.get()==3):
        text_entities_label.grid_remove()
        entity_text_widget.grid_remove()

        text_sentece_label.grid_remove()
        senteces_text_widget.grid_remove()

        part_of_speech_label.grid(row=5, column=2)
        speech_part_text_widget.grid(row=6, column=2)

# Functie pentru crearea ferestrei principale
def MainForm(username):
    global MainFrame
    MainFrame = Frame(root)
    #MainFrame.configure(height=height, width=width)
    MainFrame.pack(side=TOP)
    # crearea unui widget Canvas cu scrollbar orizontal si vertical
    canvas = Canvas(MainFrame, width=width, height=height)
    # adauga fereastra de vizualizare la canvas
    viewport = Frame(canvas)
    canvas.create_window((0, 0), window=viewport, anchor='nw')

    btn_logout = Button(viewport, text=f"Log out ({username})", font=('Times New Roman', 16, 'bold'), command=MainToggleToLogin)
    btn_logout.grid(row=1, column=1, columnspan=2, sticky="e")


    Label(viewport, text="Metode de post-procesare\n a textului generat de sistemele \n speech-to-text", font=("Times New Roman", 20)).grid(row=0, column=1)
    Label(viewport, text='Textul transcris', font=("Times New Roman", 16)).grid(row=2, column=0)
    Label(viewport, text='Text după corectarea erorilor', font=("Times New Roman", 16)).grid(row=2, column=2)
    Label(viewport, text='Selectați metoda de post-procesare a textului dorită', font=("Times New Roman", 16, "italic")).grid(row=4, column=0)

    text_entities_label=Label(viewport, text="Entitățile textului", font=("Times New Roman", 16))
    text_entities_label.grid_remove()

    part_of_speech_label=Label(viewport, text="Părțile de vorbire ale textului", font=("Times New Roman", 16))
    part_of_speech_label.grid_remove()

    text_sentece_label=Label(viewport, text="Textul despărțit în propoziții", font=("Times New Roman", 16))
    text_sentece_label.grid_remove()

    #adaugă un widget Text pentru afișarea textului preluat de la Speech-To-Text
    text_widget = Text(viewport, font=12, height=15, width=50)
    text_widget.grid(row=3, column=0)

    #adaugă un widget Text pentru afișarea textului corectat
    processed_text_widget = Text(viewport, font=12, height=15, width=50)
    processed_text_widget.grid(row=3, column=2)

    #adaugă un widget Text pentru afișarea partilor de vorbire ale textului corectat
    speech_part_text_widget = Text(viewport, font=12, height=15, width=50)
    speech_part_text_widget.grid_remove()

    #adaugă un widget Text pentru afișarea entitatilor textului corectat
    entity_text_widget = Text(viewport, font=12, height=15, width=50)
    entity_text_widget.grid_remove()

    #adaugă un widget Text pentru impartirea in propozitii a textului corectat
    senteces_text_widget = Text(viewport, font=12, height=15, width=50)
    senteces_text_widget.grid_remove()

    
    #adaugă un widget Text pentru afișarea TODO textului corectat
    #widget_last = Text(viewport, font=12, height=15, width=50)
    #widget_last.grid(row=6, column=2)

    recordbutton = Button(viewport, text='Înregistrare', bg='#333333', fg='white', font=("Times New Roman", 14), 
                          command=lambda: text_widget.insert(END, stt.recordvoice()+"\n")
                          ).grid(row=2, column=0, sticky="w")

    
    def post_process_text():
        pp.PostProcess(text_widget.get(1.0, "end-1c"),
                   processed_text_widget,
                   entity_text_widget,
                   speech_part_text_widget,
                   senteces_text_widget)

    # adaugă buton pentru post-procesare text
    process_button = Button(viewport, text='Click aici pentru corectare text', bg='#333333', fg='white', font=("Times New Roman", 14),
                        command=lambda: post_process_text() if text_widget.get(1.0, "end-1c") 
                        else 
                        messagebox.showerror("Corectare text", "Campul Textul transcris este gol.\nIncercati din nou dupa completarea campului cu semnalul vocal transcris.")
                        ).grid(row=3, column=1)

    #adauga buton de salvare fisiere text_inputs.txt si text_entities.txt
    txt_savebutton = Button(viewport, text='Salvare text în fișier .txt', bg='#333333', fg='white', 
                            font=("Times New Roman", 13),
                            command=lambda: stf.save_text_to_file(processed_text_widget.get(1.0, "end-1c"),
                                                              entity_text_widget.get(1.0, "end-1c"),
                                                              senteces_text_widget.get(1.0, "end-1c"),
                                                              speech_part_text_widget.get(1.0, "end-1c"),
                                                              username)
                                                              ).grid(row=4, column=2, sticky="w")
    
    
    mp3_save_button = Button(viewport, text='Salvare text în fișier .mp3', bg='#333333', fg='white', font=("Times New Roman", 13),
                             command=lambda: saf.save_mp3files(username, processed_text_widget.get(1.0, "end-1c"))).grid(row=4, column=2)

    view_txt_button = Button(viewport, text=' Vizualizare  fișiere  .txt', bg='#333333', fg='white', font=("Times New Roman", 13),
                             command=lambda: stf.view_txtfiles(username)).grid(row=4, column=2, sticky="e")
    
    #adauga buton pentru selectare fișier audio de tip .wav / .mp3 pentru transcriere
    select_wavfile_button = Button(viewport, text='Încărcare fișier audio', bg='#333333', fg='white', font=("Times New Roman", 14),
                                   command=lambda: text_widget.insert(END, wt.transcribe_wav_file()+"\n")
                                   ).grid(row=2, column=0, sticky="e")
    #adauga buton de iesire
    exit_button = Button(viewport, text='Ieșire',  font=("Times New Roman", 16, 'bold'), command=Exit)
    exit_button.grid(row=0, column=2, sticky="e")

    # adauga scrollbar-uri la canvas
    scrollbar_y = Scrollbar(MainFrame, orient=VERTICAL, command=canvas.yview)
    scrollbar_y.pack(side=RIGHT, fill=Y)

    scrollbar_x = Scrollbar(MainFrame, orient=HORIZONTAL, command=canvas.xview)
    scrollbar_x.pack(side=BOTTOM, fill=X)

    # seteaza legatura intre scrollbar-uri si fereastra de vizualizare a canvas-ului
    canvas.configure(yscrollcommand=scrollbar_y.set, xscrollcommand=scrollbar_x.set)

    # seteaza dimensiunea initiala a ferestrei de vizualizare a canvas-ului
    viewport.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))

    # afiseaza canvas-ul
    canvas.pack(side=LEFT, fill=BOTH, expand=TRUE)

    # Crearea butoanelor radio
    rb1 = Radiobutton(viewport, text="Afișați entitățile textului", font=("Times New Roman", 16), variable=var, value=1, 
                      command=lambda: select(text_entities_label, entity_text_widget,
           text_sentece_label, senteces_text_widget,
           part_of_speech_label, speech_part_text_widget))
    rb2 = Radiobutton(viewport, text="Afișați propozițiile textului", font=("Times New Roman", 16), variable=var, value=2, 
                      command=lambda: select(text_entities_label, entity_text_widget,
           text_sentece_label, senteces_text_widget,
           part_of_speech_label, speech_part_text_widget))
    rb3 = Radiobutton(viewport, text="Afișați părțile de vorbire ale textului", font=("Times New Roman", 16), variable=var, value=3, 
                      command=lambda: select(text_entities_label, entity_text_widget,
           text_sentece_label, senteces_text_widget,
           part_of_speech_label, speech_part_text_widget))

    # Plasarea butoanelor radio pe fereastra principală a aplicației
    rb1.grid(row=5, column=0, sticky="w")
    rb2.grid(row=5, column=0, sticky="e")
    rb3.grid(row=6, column=0, sticky="nw")

# Functie pentru crearea ferestrei de Register
def RegisterForm():
    global RegisterFrame
    global entry_register_username, entry_register_password, entry_register_email, entry_register_confirm_password

    RegisterFrame = Frame(root)
    RegisterFrame.pack(pady=200)

    lbl_username = Label(RegisterFrame, text="Username:", font=('Times New Roman', 18), bd=18)
    lbl_username.grid(row=1)

    lbl_email = Label(RegisterFrame, text="Email:", font=('Times New Roman', 18), bd=18)
    lbl_email.grid(row=2)

    lbl_password = Label(RegisterFrame, text="Password:", font=('Times New Roman', 18), bd=18)
    lbl_password.grid(row=3)

    lbl_confirm_password = Label(RegisterFrame, text="Confirm password:", font=('Times New Roman', 18), bd=18)
    lbl_confirm_password.grid(row=4)

    entry_register_username = Entry(RegisterFrame, font=('Times New Roman', 20), width=15)
    entry_register_username.grid(row=1, column=1)

    entry_register_email = Entry(RegisterFrame, font=('Times New Roman', 20), width=15)
    entry_register_email.grid(row=2, column=1)

    entry_register_password = Entry(RegisterFrame, font=('Times New Roman', 20), width=15, show="*")
    entry_register_password.grid(row=3, column=1)

    entry_register_confirm_password = Entry(RegisterFrame, font=('Times New Roman', 20), width=15, show="*")
    entry_register_confirm_password.grid(row=4, column=1)

    btn_login = Button(RegisterFrame, text="Register", font=('Times New Roman', 18), width=35, command=lambda: reg.Register(entry_register_username, entry_register_email, entry_register_password, entry_register_confirm_password))
    btn_login.grid(row=6, columnspan=2)

    btn_login_back = Button(RegisterFrame, text="Înapoi la Login", font=('Times New Roman', 18), width=35, command=lambda: ToggleToLogin())
    btn_login_back.grid(row=7, columnspan=2, )


    #adauga buton de iesire
    exit_button = Button(RegisterFrame, text='Ieșire',  font=("Times New Roman", 16, 'bold'), command=Exit)
    exit_button.grid(row=8, columnspan=2, sticky="e")

# Functii pentru crearea ferestrei de Login
def LoginUserRoleResult():
    user_array=log.Login(entry_username, entry_password)

    if(user_array[0]=="user"):
        ToogleToMainwindow(user_array[1])
    else:
        ToogleToAdminWindow(user_array[1])

def LoginForm():
    global LoginFrame
    global entry_username, entry_password

    LoginFrame = Frame(root)
    LoginFrame.pack(pady=200)

    lbl_username = Label(LoginFrame, text="Username:", font=('Times New Roman', 25), bd=18)
    lbl_username.grid(row=1)

    lbl_password = Label(LoginFrame, text="Password:", font=('Times New Roman', 25), bd=18)
    lbl_password.grid(row=2)

    entry_username = Entry(LoginFrame, font=('Times New Roman', 20), width=15)
    entry_username.grid(row=1, column=1)

    entry_password = Entry(LoginFrame, font=('Times New Roman', 20), width=15, show="*")
    entry_password.grid(row=2, column=1)

    btn_login = Button(LoginFrame, text="Login", font=('Times New Roman', 18), width=35, command=lambda: LoginUserRoleResult())
    btn_login.grid(row=4, columnspan=2)

    btn_register = Button(LoginFrame, text="Register", font=('Times New Roman', 18), width=35, command=lambda: ToggleToRegister())
    btn_register.grid(row=5, columnspan=2)

    btn_demo = Button(LoginFrame, text="Încearcă aplicația fără înregistrare", font=('Times New Roman', 18, 'italic', 'underline'), bd=0, width=35, command=lambda: ToogleToMainwindow("demo"))
    btn_demo.grid(row=6, columnspan=2)

    #adauga buton de iesire
    exit_button = Button(LoginFrame, text='Ieșire',  font=("Times New Roman", 16, 'bold'), command=Exit)
    exit_button.grid(row=7, columnspan=2, sticky="e")

# Functii pentru crearea ferestrei de admin
def delete_user(admin_name):
    
    # Utilizați o casetă de dialog pentru a cere adminului numele utilizatorului care urmeaza sa fie sters.
    username = simpledialog.askstring("Ștergere utilizator", f"Introduceți numele utilizatorului pe care doriti sa-l stergeti.")

    # Verific dacă utilizatorul există deja în baza de date
    coll = DB.db.Users
    existing_user = coll.find_one({"username": username})
    if existing_user:
        # definește query-ul pentru utilizatorul respectiv
        query = {"username": username}

        # extrage utilizatorul respectiv
        this_user = DB.users_collection.find_one(query)
    
        # get the "role" field of the current user
        role = this_user.get("role")
    
        #print(f"{username}  {role}")

        if(role=="user"):
            # afișează un mesaj de succes
            messagebox.showinfo("Stergere utilizator", f"Utilizatorul {this_user['username']} a fost șters cu succes din baza de date a aplicației.")
        
            # șterge utilizatorul din baza de date
            DB.users_collection.delete_one(query)
        
            #actualizeaza tabelul
            refresh_table(admin_name)

        if(role=="admin"):
            messagebox.showerror("Stergere utilizator", f"Nu puteți șterge utilizatorul {this_user['username']} de tip admin.")
    
    if(not(existing_user)):
        messagebox.showerror("Stergere utilizator", f"Utilizatorul  {username} nu exista in baza de date.\nIncercati din nou.")
        #return

def refresh_table(admin_name):
    # Ștergerea tuturor elementelor din tabel
    for widget in AdminFrame.winfo_children():
        widget.destroy()

    create_Adminpage(admin_name)

def edit_user(admin_name):
    
    # Utilizați o casetă de dialog pentru a cere adminului numele utilizatorului care urmeaza sa fie editat.
    username = simpledialog.askstring("Editare utilizator", f"Introduceți numele utilizatorului pe care doriti sa-l editati.")

    # Verific dacă utilizatorul există în baza de date
    coll = DB.db.Users
    existing_user = coll.find_one({"username": username})

    if existing_user:
        # definește query-ul pentru utilizatorul respectiv
        query = {"username": username}

        # extrage utilizatorul respectiv
        this_user = DB.users_collection.find_one(query)

        root.state('zoomed')

        canvas_user_details(admin_name, this_user, query)

    else:
        messagebox.showerror("Editare utilizator", f"Utilizatorul  {username} nu exista in baza de date.\nIncercati din nou.")
        #return

def save_edited_values(admin_name, query,
                       edit_entry_username,
                       edit_entry_password,
                       edit_entry_email,
                       edit_entry_role):
    
     # preluarea valorii din Entry
    new_username = edit_entry_username.get()
    new_password = edit_entry_password.get()
    new_email = edit_entry_email.get()
    new_role = edit_entry_role.get()

    # actualizarea documentului în baza de date
    DB.users_collection.update_one(query, {'$set': {'username': new_username}})
    DB.users_collection.update_one(query, {'$set': {'password': new_password}})
    DB.users_collection.update_one(query, {'$set': {'email': new_email}})
    DB.users_collection.update_one(query, {'$set': {'role': new_role}})

    messagebox.showinfo("Editare utilizator", "Datele utilizatorului au fost modificate cu succes.")

    refresh_table(admin_name)

def canvas_user_details(admin_name, this_user, query):
    # Ștergerea tuturor elementelor din AdminFrame
    for widget in AdminFrame.winfo_children():
        widget.destroy()

    # crearea unui widget Canvas cu scrollbar orizontal si vertical
    canvas = Canvas(AdminFrame)
    canvas.pack(side=LEFT, fill=BOTH, expand=1)

    scrollbar_y = Scrollbar(AdminFrame, orient=VERTICAL, command=canvas.yview)
    scrollbar_y.pack(side=RIGHT, fill=Y)

    scrollbar_x = Scrollbar(AdminFrame, orient=HORIZONTAL, command=canvas.xview)
    scrollbar_x.pack(side=BOTTOM, fill=X)

    canvas.configure(xscrollcommand=scrollbar_x.set, yscrollcommand=scrollbar_y.set)
    canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

    # adaugarea unui frame interior pentru afisarea elementelor din tabel
    table_inner_frame = Frame(canvas)

    # Adăugarea antetului tabelului
    Label(table_inner_frame, text="Username", font=("Times New Roman", 14, 'bold')).grid(row=0, column=0, padx=5, pady=5, sticky="wn")
    Label(table_inner_frame, text="Password", font=("Times New Roman", 14, 'bold')).grid(row=0, column=1, padx=5, pady=5, sticky="wn")
    Label(table_inner_frame, text="Email", font=("Times New Roman", 14, 'bold')).grid(row=0, column=2, padx=5, pady=5, sticky="wn")
    Label(table_inner_frame, text="Role", font=("Times New Roman", 14, 'bold')).grid(row=0, column=3, padx=5, pady=5, sticky="wn")

    # get the fields of the current user
    username = this_user.get("username")
    password = this_user.get("password")
    email = this_user.get("email")
    role = this_user.get("role")

    edit_entry_username = Entry(table_inner_frame, font=('Times New Roman', 14))
    edit_entry_username.grid(row=1, column=0, padx=5, pady=5, sticky="wn")
    edit_entry_username.insert(0, f"{username}")

    edit_entry_password = Entry(table_inner_frame, font=('Times New Roman', 14))
    edit_entry_password.grid(row=1, column=1, padx=5, pady=5, sticky="wn")
    edit_entry_password.insert(0, f"{password}")

    edit_entry_email = Entry(table_inner_frame, font=('Times New Roman', 14))
    edit_entry_email.grid(row=1, column=2, padx=5, pady=5, sticky="wn")
    edit_entry_email.insert(0, f"{email}")

    edit_entry_role = Entry(table_inner_frame, font=('Times New Roman', 14))
    edit_entry_role.grid(row=1, column=3, padx=5, pady=5, sticky="wn")
    edit_entry_role.insert(0, f"{role}")

    # adaugarea butonului de salvare modificari
    save_button = Button(table_inner_frame, text="Salvare modificari", font=("Times New Roman", 15),
                         command=lambda: save_edited_values(admin_name, query,
                                                            edit_entry_username,
                                                            edit_entry_password,
                                                            edit_entry_email,
                                                            edit_entry_role))
    save_button.grid(row=2, column=0, padx=5, pady=5, sticky="wn")

    back_button = Button(table_inner_frame, text="Înapoi", font=("Times New Roman", 15), command=lambda: refresh_table(admin_name))
    back_button.grid(row=2, column=1)

    # adaugarea butonului de iesire
    exit_button = Button(table_inner_frame, text="Ieșire", font=("Times New Roman", 16),
                           command=Exit, borderwidth=0)
    exit_button.grid(row=0, column=4, padx=5, pady=5, sticky="n")


    canvas_center = (width / 2, 0)
    canvas.create_window(canvas_center, window=table_inner_frame, anchor='n')

def create_Adminpage(admin_name):

    number=1

    # crearea unui widget Canvas cu scrollbar orizontal si vertical
    canvas = Canvas(AdminFrame)
    canvas.pack(side=LEFT, fill=BOTH, expand=1)

    scrollbar_y = Scrollbar(AdminFrame, orient=VERTICAL, command=canvas.yview)
    scrollbar_y.pack(side=RIGHT, fill=Y)

    scrollbar_x = Scrollbar(AdminFrame, orient=HORIZONTAL, command=canvas.xview)
    scrollbar_x.pack(side=BOTTOM, fill=X)

    canvas.configure(xscrollcommand=scrollbar_x.set, yscrollcommand=scrollbar_y.set)
    canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

    # adaugarea unui frame interior pentru afisarea elementelor din tabel
    table_inner_frame = Frame(canvas)

    # Adăugarea antetului tabelului
    Label(table_inner_frame, text="#    ", font=("Times New Roman", 18, 'bold')).grid(row=0, column=0, padx=5, pady=5, sticky="n")
    Label(table_inner_frame, text="Username", font=("Times New Roman", 18, 'bold')).grid(row=0, column=1, padx=5, pady=5, sticky="n")
    Label(table_inner_frame, text="Rol", font=("Times New Roman", 18, 'bold')).grid(row=0, column=2, padx=5, pady=5, sticky="n")

    # iterarea prin lista de utilizatori
    for i, user in enumerate(DB.users_collection.find()):
        # adaugarea unui nou rand in grila de afisare
        AdminFrame.rowconfigure(i, weight=1)

        # afisarea numarului utilizatorului
        nr_label = Label(table_inner_frame, text=f"{number}", font=("Times New Roman", 18))
        nr_label.grid(row=i+1, column=0, padx=5, pady=5, sticky="n")

        # afisarea username-ului utilizatorului
        username_label = Label(table_inner_frame, text=user['username'], font=("Times New Roman", 18))
        username_label.grid(row=i+1, column=1, padx=5, pady=5, sticky="n")

        # afisarea rolului utilizatorului
        role_label = Label(table_inner_frame, text=user['role'], font=("Times New Roman", 18))
        role_label.grid(row=i+1, column=2, padx=5, pady=5, sticky="n")
    
        number=number+1
    
    # adaugarea butonului de editare utilizator
    edit_button = Button(table_inner_frame, text="Editare utilizator", font=("Times New Roman", 18),
                         command=lambda: edit_user(admin_name))
    edit_button.grid(row=1, column=3, padx=5, pady=5, sticky="n")

    # adaugarea butonului de stergere utilizator
    delete_button = Button(table_inner_frame, text="Stergere utilizator", font=("Times New Roman", 18),
                            command=lambda: delete_user(admin_name))
    delete_button.grid(row=1, column=4, padx=5, pady=5, sticky="n")
        

    # adaugarea butonului de logout
    logout_button = Button(table_inner_frame, text=f"Logout ({admin_name})", font=("Times New Roman", 16, 'bold'),
                           command=lambda: AdminToggleToLogin())
    logout_button.grid(row=0, column=4, padx=5, pady=5, sticky="n")

    # adaugarea butonului de iesire
    exit_button = Button(table_inner_frame, text="Ieșire", font=("Times New Roman", 16, 'bold'),
                           command=Exit)
    exit_button.grid(row=0, column=5, padx=5, pady=5, sticky="n")

    canvas_center = (width / 2, 0)
    canvas.create_window(canvas_center, window=table_inner_frame, anchor='n')

def AdminForm(admin_name):
    # crearea frame-ului cu utilizatori
    global AdminFrame
    AdminFrame = Frame(root)
    AdminFrame.pack(fill=BOTH, expand=1)
    global number
    create_Adminpage(admin_name)
  
# Functii pentru a face switch intre ferestre
def ToggleToLogin(event=None):
    RegisterFrame.destroy()
    LoginForm()

def ToggleToRegister(event=None):
    LoginFrame.destroy()
    RegisterForm()

def ToogleToMainwindow(username):
    LoginFrame.destroy()
    MainForm(username)

def MainToggleToLogin(event=None):
    MainFrame.destroy()
    LoginForm()

def ToogleToAdminWindow(admin_name):
    LoginFrame.destroy()
    AdminForm(admin_name)

def AdminToggleToLogin(event=None):
    AdminFrame.destroy()
    LoginForm()

#Initializare
#MainForm()
LoginForm()

if __name__ == '__main__':

    root.mainloop()