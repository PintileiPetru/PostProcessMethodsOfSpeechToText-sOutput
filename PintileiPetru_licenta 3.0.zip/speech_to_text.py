import speech_recognition as sr
from tkinter import messagebox

def recordvoice():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        audio = r.listen(source)
        try:
            text = r.recognize_google(audio, language="ro-RO")
        except sr.UnknownValueError:
            messagebox.showerror("Eroare de recunoaștere vocală", "Nu am putut recunoaște ce ai spus. Te rog să repeți.")
        except sr.RequestError:
            messagebox.showerror("Eroare", "Eroare în serviciul de recunoaștere vocală.")
        return text

def stop_recording():
    # Funcție pentru a opri înregistrarea
    global recording
    recording = False