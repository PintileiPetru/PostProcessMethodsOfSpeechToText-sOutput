import os
from tkinter import messagebox
import connect_to_database as DB

# definim o functie care deschide fisierele "text_inputs", "text_entities.txt", "text_senteces.txt", "text_speech_parts.txt"
#  la apasarea butonului Vizualizare fisiere .txt
def view_txtfiles(username):
    # Calea către fișierele "text_inputs", "text_entities.txt", "text_senteces.txt", "text_speech_parts.txt"
    # obține calea completă a fișierului
    current_location = os.getcwd()
    cale_text_inputs = os.path.join(current_location, "Users", f"{username}", f"{username}_text_inputs.txt")
    cale_text_entities = os.path.join(current_location, "Users", f"{username}", f"{username}_text_entities.txt")
    cale_text_senteces = os.path.join(current_location, "Users", f"{username}", f"{username}_text_senteces.txt")
    cale_text_speech_parts = os.path.join(current_location, "Users", f"{username}", f"{username}_text_speech_parts.txt")

    # Verificăm dacă fișierul există
    if os.path.exists(cale_text_inputs):
        # Lansăm comanda de deschidere cu programul implicit
        os.startfile(cale_text_inputs)
    else:
        messagebox.showerror("txt file", f"Fișierul {cale_text_inputs} nu există!")

    if os.path.exists(cale_text_entities):
        # Lansăm comanda de deschidere cu programul implicit
        os.startfile(cale_text_entities)
    else:
        messagebox.showerror("txt file", f"Fișierul {cale_text_entities} nu există!")

    if os.path.exists(cale_text_senteces):
        # Lansăm comanda de deschidere cu programul implicit
        os.startfile(cale_text_senteces)
    else:
        messagebox.showerror("txt file", f"Fișierul {cale_text_senteces} nu există!")

    if os.path.exists(cale_text_speech_parts):
        # Lansăm comanda de deschidere cu programul implicit
        os.startfile(cale_text_speech_parts)
    else:
        messagebox.showerror("txt file", f"Fișierul {cale_text_speech_parts} nu există!")

#Contor pentru liniile din fisierele demo
demo_counter=1
Edemo_counter=1
Sdemo_counter=1
SPdemo_counter=1

#Creare fisier "text_inputs.txt", "text_entities.txt", "text_senteces.txt", "text_speech_parts.txt"
def save_text_to_file(processed_text, entity_text, senteces_text, speech_part_text, username):
    global demo_counter, Edemo_counter, Sdemo_counter, SPdemo_counter

    # defineste calea catre folder
    folder_path = os.path.join(os.getcwd(), "Users")
    user_folder_path = os.path.join(folder_path, username)
    
    # daca folderul nu exista, il creeaza
    if not os.path.exists(user_folder_path):
        os.makedirs(user_folder_path)
    
    demo_file_path = os.path.join(folder_path, "demo")
    # daca folderul nu exista, il creeaza
    if not os.path.exists(demo_file_path):
        os.makedirs(demo_file_path)
    

    # defineste calea catre fisierele "text_inputs", "text_entities.txt", "text_senteces.txt", "text_speech_parts.txt"
    text_file_path = os.path.join(user_folder_path, f"{username}_text_inputs.txt")
    entity_file_path = os.path.join(user_folder_path, f"{username}_text_entities.txt")
    senteces_file_path = os.path.join(user_folder_path, f"{username}_text_senteces.txt")
    speech_part_file_path = os.path.join(user_folder_path, f"{username}_text_speech_parts.txt")
    

    text_demo_file_path = os.path.join(demo_file_path, "demo_text_inputs.txt")
    entity_demo_file_path = os.path.join(demo_file_path, "demo_text_entities.txt")
    senteces_demo_file_path = os.path.join(demo_file_path, "demo_text_senteces.txt")
    speech_part_demo_file_path = os.path.join(demo_file_path, "demo_text_speech_parts.txt")

    if username!="demo":
        # definește query-ul pentru utilizatorul curent
        query = {"username": username}

        # Actualizați utilizatorul adăugând noile valori la sfârșitul listelor "text_inputs", "text_entities", "text_senteces", "text_speech_parts"
        if (processed_text!=""):
            DB.users_collection.update_one(query, {"$push": {"text_inputs": processed_text}})
            DB.users_collection.update_one(query, {"$push": {"text_entities": entity_text}})
            DB.users_collection.update_one(query, {"$push": {"text_senteces": senteces_text}})
            DB.users_collection.update_one(query, {"$push": {"text_speech_parts": speech_part_text}})
        else:
            messagebox.showerror("txt file", "Câmpul <Text după corectarea erorilor> este gol.\nÎncercați din nou.")

             
        # extrage utilizatorul curent
        this_user = DB.users_collection.find_one(query)

        # obține vectorul "text_inputs" al utilizatorului curent
        text_inputs = this_user.get("text_inputs")
        text_entities = this_user.get("text_entities")
        text_senteces = this_user.get("text_senteces")
        text_speech_parts = this_user.get("text_speech_parts")


    # contor pentru liniile din fisiere
    counter=1

    if username!="demo":
        if processed_text!="":
            try:
            
                # deschide fișierul text_inputs.txt în modul de scriere
                with open(text_file_path, "w", encoding="utf-8") as file:
                    # scrie fiecare text din vectorul "text_inputs" pe o linie nouă în fișier
                        for value in text_inputs:
                            file.write(str(str(counter) + "-> " + value + "\n"))
                            counter+=1

                counter=1
                # deschide fișierul text_entities.txt în modul de scriere
                with open(entity_file_path, "w", encoding="utf-8") as file:
                    # scrie fiecare text din vectorul "text_entities" pe o linie nouă în fișier
                        for value in text_entities:
                            if (value!=""):
                                file.write(str(str(counter) + "-> " + value + "\n"))
                            else:
                                file.write(str(str(counter) + "-> " + f"In textul cu indexul {counter} nu a fost gasita nicio entitate.\n"))
                        
                            counter+=1

                counter=1
                # deschide fișierul text_senteces.txt în modul de scriere
                with open(senteces_file_path, "w", encoding="utf-8") as file:
                    # scrie fiecare text din vectorul "text_inputs" pe o linie nouă în fișier
                        for value in text_senteces:
                            file.write(str(str(counter) + "-> " + value + "\n"))
                            counter+=1

                counter=1
                # deschide fișierul text_speech_parts.txt în modul de scriere
                with open(speech_part_file_path, "w", encoding="utf-8") as file:
                    # scrie fiecare text din vectorul "text_inputs" pe o linie nouă în fișier
                        for value in text_speech_parts:
                            file.write(str(str(counter) + "-> " + value + "\n"))
                            counter+=1
            
                messagebox.showinfo("txt file", f"Fisierele {text_file_path}\n{entity_file_path}\n{senteces_file_path}\n{speech_part_file_path}\n au fost actualizate cu succes!")

            except ValueError:
                messagebox.showinfo("txt file", "Eroare la salvarea fisierului text_inputs.txt. Incercati din nou.")
            except TypeError:
                messagebox.showinfo("txt file", "Eroare la salvarea fisierului text_inputs.txt. Incercati din nou.")
        
    else:
        try:
            # deschide fișierul text_inputs.txt în modul de scriere
            with open(text_demo_file_path, "a", encoding="utf-8") as file:
                # scrie fiecare text din vectorul "text_inputs" pe o linie nouă în fișier
                if (processed_text!=""):
                    file.write(str(str(demo_counter) + "-> " + processed_text + "\n"))
                    demo_counter+=1
                else:
                    messagebox.showerror("txt file", "Campul <Text după corectarea erorilor> este gol.\nÎncercați din nou.")
            
            # deschide fișierul text_entities.txt în modul de scriere
            with open(entity_demo_file_path, "a", encoding="utf-8") as file:
                # scrie fiecare text din vectorul "text_entities" pe o linie nouă în fișier
                    if (processed_text!=""):
                        if (entity_text!=""):
                            file.write(str(str(Edemo_counter) + "-> " + entity_text + "\n"))
                            messagebox.showinfo("txt file", f"Fisierele {text_demo_file_path}\n{entity_demo_file_path}\n{senteces_demo_file_path}\n{speech_part_demo_file_path}\n au fost actualizate cu succes!")
                        else:
                            file.write(str(str(Edemo_counter) + "-> " + f"In textul cu indexul {Edemo_counter} nu a fost gasita nicio entitate.\n"))
                            messagebox.showinfo("txt file", f"Fisierele {text_demo_file_path}\n{entity_demo_file_path}\n{senteces_demo_file_path}\n{speech_part_demo_file_path}\n au fost actualizate cu succes!")
                        Edemo_counter = Edemo_counter + 1

            # deschide fișierul text_senteces.txt în modul de scriere
            with open(senteces_demo_file_path, "a", encoding="utf-8") as file:
                # scrie fiecare text din vectorul "text_sentece" pe o linie nouă în fișier
                    if (senteces_text!=""):
                        file.write(str(str(Sdemo_counter) + "-> " + senteces_text + "\n"))
                        Sdemo_counter = Sdemo_counter + 1

            # deschide fișierul text_speech_parts.txt în modul de scriere
            with open(speech_part_demo_file_path, "a", encoding="utf-8") as file:
                # scrie fiecare text din vectorul "text_speech_parts" pe o linie nouă în fișier
                    if (speech_part_text!=""):
                        file.write(str(str(SPdemo_counter) + "-> " + speech_part_text + "\n"))
                        SPdemo_counter = SPdemo_counter + 1

        except ValueError:
            messagebox.showinfo("txt file", "Eroare la salvarea fisierului text_inputs.txt. Incercati din nou.")
        except TypeError:
            messagebox.showinfo("txt file", "Eroare la salvarea fisierului text_inputs.txt. Incercati din nou.")