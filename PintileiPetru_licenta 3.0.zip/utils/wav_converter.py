import soundfile as sf
import os

# Set permissions for all files and directories within a directory to "rwxrwxrwx"
for root, dirs, files in os.walk("/Audio_files"):
    for d in dirs:
        os.chmod(os.path.join(root, d), 0o777)
    for f in files:
        os.chmod(os.path.join(root, f), 0o777)

# Specify input and output file paths
input_file = "./Audio_files/transcript.mp3"
output_file = "./Audio_files/audio.wav"

# Load the audio file using soundfile
audio_data, sample_rate = sf.read(input_file)

# Convert the audio to WAV format and save the output file using soundfile
sf.write(output_file, audio_data, sample_rate, format="WAV")
