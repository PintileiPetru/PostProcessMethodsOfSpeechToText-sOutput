	Pentru rularea aplicatiei, recomand utilizarea versiunii 3.6.7 de python

	In cele 2 fisiere, MainWindow.png si textFiles.png aveti o simulare a folosirii aplicatiei.	

	In text widgetul din partea stanga se scrie textul pe care doriti sa l post-procesati apasand butonul "Click here to post-process text".
Rezultatul post-procesarii textului va fi inserat in text widget-ul din partea dreapta sus, iar entitatile gasite vor fi inserate in text widgetul din partea dreapta jos.
Momentan, pentru post-procesare folosesc modelul Spacy gata implementat.

	Apasand butonul "Save processed text and text entities as .txt files", acesta va apela o functie care creeaza in folderul /Users/Inputs cele 2 fisiere .txt: text_inputs.txt si text_entities.txt
In primul fisier se va salva (numerotand fiecare intrare) continutul text widgetului din dreapta sus (Adica textul post-procesat), iar in al doilea fisier se va salva (numerotand fiecare intrare) continutul text widgetului din partea dreapta jos (Adica entitatile gasite).

	Prin apasarea butonului "View .txt files", sistemul de operare va deschide cele doua fisiere mai sus mentionate.


	exit  -> inchidere aplicatie.

#Valoarea implicită a limitei de caractere pentru procesarea unui text în spaCy este 1.000.000 de caractere
#Această valoare poate fi modificată prin setarea valorii parametrului nOversize în configurația modelului spaCy.

	In aplicatie, momentan am folosit ('ro_core_news_md') # varianta mare (40 MB), iar in viitorul apropiat voi folosi ro_core_news_lg -> varianta foarte MARE (542 MB). Momentan n-am reusit sa o descarc pentru ca nu dispun de conexiune buna la internet (Sunt pe tren).

    # Încărcați modelul Sapcy pentru limba romana
    nlp = spacy.load('ro_core_news_md') # varianta mare (40 MB)
    # ro_core_news_sm -> pentru varianta mica (12 MB)
    # ro_core_news_lg -> pentru varianta foarte MARE (542 MB)
    # se descarca cu comanda:
    # python -m spacy download ro_core_news_lg