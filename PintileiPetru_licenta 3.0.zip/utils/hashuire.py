import hashlib

password = "ioan"

# Creare instanță sha256
sha256 = hashlib.sha256()

# Convertirea parolei în bytes
password_bytes = password.encode('utf-8')

# Aplicarea sha256 pe parolă
sha256.update(password_bytes)

# Obținerea valorii hash pentru parolă
hashed_password = sha256.hexdigest()

print(hashed_password)
