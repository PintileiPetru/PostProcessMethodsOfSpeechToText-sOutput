
# Exemplu de date de antrenare
train_data = [
    ("Am merge la film astăseară?", {"cats": {"MISPELLED": 1.0}}),
    ("Am mers la film astăseară.", {"cats": {"CORRECT": 1.0}}),
    ("Mi-a plăcut mult filmul.", {"cats": {"CORRECT": 1.0}}),
    ("Filmul a fost foarte bun.", {"cats": {"CORRECT": 1.0}}),
    ("A fost un film interesant.", {"cats": {"CORRECT": 1.0}}),
    ("A fost un film interezant.", {"cats": {"MISPELLED": 1.0}}),
    ("Îmi place să merg la mare.", {"cats": {"CORRECT": 1.0}}),
    ("Îmi place să merg la mre.", {"cats": {"MISPELLED": 1.0}}),
    ("Vreau să merg la teatru.", {"cats": {"CORRECT": 1.0}}),
    ("Vreau să merg la teatur.", {"cats": {"MISPELLED": 1.0}}),
]

# importam librariile necesare
from keras.models import Sequential
from keras.layers import Dense, LSTM, Embedding
from keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing import sequence
from sklearn.model_selection import train_test_split

# colectam si preprocesam datele
text_data = ["Aceasta este o propozitie de exemplu.",
            "Cainele a fugit prin parc.",
            "Am merz la film astăseară?",
            "Mia placut mult filmul.", 
            "A fost un film interezant.",
            "Îmi place să merg la mre.",
            "Vreau să merg la teatur."]

corrected_data = ["Aceasta este o propoziție de exemplu.",
                   "Câinele a fugit prin parc.",
                   "Am mers la film astăseară.",
                   "Mi-a plăcut mult filmul.",
                   "A fost un film interesant.",
                   "Îmi place să merg la mare.",
                   "Vreau să merg la teatru."
                   ]

tokenizer = Tokenizer(num_words=10000)
tokenizer.fit_on_texts(text_data)


X = tokenizer.texts_to_sequences(text_data)
X = sequence.pad_sequences(X, maxlen=50)

y = tokenizer.texts_to_sequences(corrected_data)
y = sequence.pad_sequences(y, maxlen=50)

# split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# pad sequences for training and testing sets
X_train = sequence.pad_sequences(X_train, maxlen=50)
X_test = sequence.pad_sequences(X_test, maxlen=50)

# construim si antrenam modelul
model = Sequential()
model.add(Embedding(10000, 32))
model.add(LSTM(64))
model.add(Dense(50, activation='softmax'))

model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
model.fit(X, y, epochs=10, batch_size=32, validation_split=0.2)

# evaluam modelul
score = model.evaluate(X_test, y_test, batch_size=32)
print("Acuratete: %.2f%%" % (score[1]*100))
